﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddAccount : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void DetailsView1_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
    {
        if (e.Exception != null)
        {
            ErrorLabel.Text = "Create Account Unsuccessful. Maybe caused by database outage OR User ID already exists. ";

            ErrorLabel.Text = e.Exception.Message;
            e.ExceptionHandled = true;
        }
       
    }
}
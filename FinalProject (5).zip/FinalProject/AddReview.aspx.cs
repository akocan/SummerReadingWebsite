﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AddReview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["FirstName"] == null)
        {
            Response.Redirect("Home.aspx");
        }
    }


    protected void DetailsView1_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
    {

    }

    protected void DetailsView1_ItemInserted(object sender, DetailsViewInsertedEventArgs e)
    {
        if (e.Exception == null)
        {
            Response.Redirect("BookReviews.aspx");
        }
        else
        {
            ErrorLabel.Text = "Add Review Unsuccessful. Maybe caused by database outage. ";

            ErrorLabel.Text = e.Exception.Message;
            e.ExceptionHandled = true;
        }
    }

    protected void DetailsView1_ItemInserting(object sender, DetailsViewInsertEventArgs e)
    {
        e.Values["UserID_FK"] = Session["UserID_PK"].ToString();
    }

    protected void DetailsView1_PageIndexChanging1(object sender, DetailsViewPageEventArgs e)
    {

    }
}
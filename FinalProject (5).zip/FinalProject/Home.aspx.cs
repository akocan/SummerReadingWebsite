﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void CreateAccountButton_Click(object sender, EventArgs e)
    {

    }



    protected void LoginButton_Click(object sender, EventArgs e)
    {
        SqlDataSource objDS = new SqlDataSource();

        objDS.ProviderName = System.Configuration.ConfigurationManager.ConnectionStrings["BookConnectionString"].ProviderName;
        objDS.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["BookConnectionString"].ConnectionString;

        objDS.SelectCommand = "select UserID_PK, FirstName, LastName from USER_T where UserID_PK=? and Password=?";

        objDS.SelectParameters.Add("UserID_PK", TextBoxUserName.Text);
        objDS.SelectParameters.Add("Password", TextBoxPassword.Text);

        objDS.DataSourceMode = SqlDataSourceMode.DataReader;

        System.Data.IDataReader bookData = (System.Data.IDataReader)objDS.Select(DataSourceSelectArguments.Empty);

        if (bookData.Read())
        {
            Session["UserID_PK"] = bookData[0];
            Session["FirstName"] = bookData[1];
            Session["LastName"] = bookData[2];
            
            Response.Redirect("Account.aspx");
        }
        else
        {
            LabelUserResults.Text = "Invalid User Name or Password, please try again.";
        }
    }

    protected void CreateAccountButton_Click1(object sender, EventArgs e)
    {
        Response.Redirect("AddAccount.aspx");
    }
}